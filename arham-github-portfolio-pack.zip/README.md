# Job Research, Accounting, Finance & Bookkeeping Portfolio

**Owner:** Muhammad Arham  
**GitHub:** [@arham123axe](https://github.com/arham123axe)

## Project purpose
This repository is a practical portfolio of templates and process examples for job research, job application tracking, spreadsheet support, bookkeeping, and basic financial analysis. It is intended to demonstrate an organized approach to administrative and finance-support work.

## Services covered
- **Job research and application tracking:** recording vacancies, deadlines, application status, and follow-up dates.
- **Excel and Google Sheets support:** structured trackers, reconciliations, summaries, and formula-based schedules.
- **Bookkeeping support:** transaction recording, cash book maintenance, ledger organization, and bank-reconciliation workflows.
- **QuickBooks support:** bookkeeping workflow planning, transaction categorization, and review checklists. QuickBooks work should only be described as hands-on experience where it has actually been performed.
- **Accounting and financial analysis:** basic financial statements, working-capital monitoring, and financial-ratio calculations.

## Repository contents
| File | Purpose |
|---|---|
| `job-research-accounts-finance-templates.xlsx` | Job tracker, cash book, general ledger, financial ratios, and bookkeeping workflow sheets |
| `README.md` | Project overview, scope, and usage notes |

## How to use the workbook
1. Download the Excel workbook.
2. Replace illustrative rows with your own data.
3. Add source links and dates to the job tracker.
4. Enter supported transactions in the cash book and general ledger.
5. Enter verified financial statement figures before interpreting ratios.
6. Review reconciliations and supporting documents before relying on any report.

## Important data and accuracy note
All sample names, amounts, dates, and transactions in the workbook are **illustrative examples only**. They are not client records, actual job placements, verified business results, or evidence of paid engagements. Do not upload confidential client, employer, or personal information to a public repository.

## Current project status
This is an initial portfolio project. Its reach and impact should be reported using real evidence only, such as repository visits, downloads, genuine user feedback, completed sample work, or verified client outcomes. No usage or client statistics are claimed here.

## Planned improvements
- Add anonymized, clearly labelled sample bookkeeping cases.
- Add a bank reconciliation template.
- Add a monthly management accounts checklist.
- Add documented Excel formulas and usage instructions.
- Add screenshots or examples only when they contain no confidential information.

## Contact
For project enquiries, use the contact details listed on the GitHub profile.
